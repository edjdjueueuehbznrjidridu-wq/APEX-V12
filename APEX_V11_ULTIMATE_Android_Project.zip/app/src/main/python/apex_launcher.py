"""Android bootstrap for the unchanged APEX Python backend.

The original analytics module is imported as-is. This wrapper only starts/stops
the existing local HTTP server and exposes lightweight health diagnostics.
"""
import threading
from http.server import ThreadingHTTPServer
import kucoin_analytics_v9_apex as backend

HOST = "127.0.0.1"
PORT = 8765
_server = None
_server_thread = None
_lock = threading.RLock()


def start_server():
    """Initialize the existing database and start exactly one local server."""
    global _server, _server_thread
    with _lock:
        if _server is not None:
            return "already_started"
        backend.db_init()
        server = ThreadingHTTPServer((HOST, PORT), backend.Handler)
        server.daemon_threads = True
        server.allow_reuse_address = True
        thread = threading.Thread(
            target=server.serve_forever, name="APEX-Backend", daemon=True
        )
        try:
            thread.start()
        except Exception:
            server.server_close()
            raise
        _server, _server_thread = server, thread
        return "started"


def health():
    """Return basic process health without changing existing backend endpoints."""
    with _lock:
        return {
            "server_started": _server is not None,
            "thread_alive": bool(_server_thread and _server_thread.is_alive()),
            "host": HOST,
            "port": PORT,
        }


def stop_server():
    """Stop cleanly if requested by the Android host or a test."""
    global _server, _server_thread
    with _lock:
        server, thread = _server, _server_thread
        _server = _server_thread = None
    if server is not None:
        try:
            server.shutdown()
        finally:
            server.server_close()
    if thread is not None and thread.is_alive():
        thread.join(timeout=2.0)
    return "stopped"
