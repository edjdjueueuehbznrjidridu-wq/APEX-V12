#!/usr/bin/env python3
"""Offline project integrity checks; no network/API requests are made."""
from pathlib import Path
import ast, hashlib, re, sys
root = Path(__file__).resolve().parents[1]
backend = root / "app/src/main/python/kucoin_analytics_v9_apex.py"
source = backend.read_bytes()
expected = "b83d5a75c13b6cf41f8701a0405be961b3a54b3b1c971639ee6a8fd6f8c9e09d"
actual = hashlib.sha256(source).hexdigest()
if actual != expected:
    raise SystemExit("FAIL: original backend source hash changed")
ast.parse(source.decode("utf-8"), filename=str(backend))
text = source.decode("utf-8")
required = ["class Handler", "def do_GET", "def do_POST", "def db_init", "ThreadingHTTPServer"]
missing = [x for x in required if x not in text]
if missing:
    raise SystemExit("FAIL: expected backend structures missing: " + ", ".join(missing))
launcher = (root / "app/src/main/python/apex_launcher.py").read_text(encoding="utf-8")
for marker in ["def start_server", "def stop_server", "def health", "backend.Handler"]:
    if marker not in launcher:
        raise SystemExit("FAIL: launcher marker missing: " + marker)
icon = root / "app/src/main/assets/trading_ai_icon.png"
if not icon.exists() or icon.stat().st_size < 10000:
    raise SystemExit("FAIL: approved icon asset missing or unexpectedly small")
print("PASS: original backend SHA-256 unchanged")
print("PASS: Python syntax and core server structures verified")
print("PASS: Android launcher wrapper and approved icon present")
print("NOTE: these checks do not replace a successful Android build or on-device tests")
